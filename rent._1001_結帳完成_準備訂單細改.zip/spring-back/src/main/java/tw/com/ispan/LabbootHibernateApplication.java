package tw.com.ispan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabbootHibernateApplication {
	public static void main(String[] args) {
		SpringApplication.run(LabbootHibernateApplication.class, args);
	}
}
