<template>

  <h1 style="font-family: '微軟正黑體', sans-serif; font-size: xx-large; font-weight: bold;"> 
	</h1>

	<Carousel></Carousel>












</template>

<script setup>
import Carousel from '@/components/Carousel.vue';
import useUserStore from '@/stores/user';
const userStore = useUserStore();
</script>
<style></style>
