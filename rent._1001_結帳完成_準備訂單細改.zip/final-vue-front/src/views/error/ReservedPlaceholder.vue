<template>
    <h1 style="font-family: '微軟正黑體', sans-serif; font-weight: bold;">預留頁面</h1>
    <h2 style="font-family: '微軟正黑體', sans-serif; font-weight: bold;">預留給未來的功能</h2>
    <h3 style="font-family: '微軟正黑體', sans-serif; font-weight: bold;">最後會刪掉</h3>
    <h4 style="font-family: '微軟正黑體', sans-serif; font-weight: bold;">請不要修改</h4>
</template>

<script setup>

</script>
<style>

</style>