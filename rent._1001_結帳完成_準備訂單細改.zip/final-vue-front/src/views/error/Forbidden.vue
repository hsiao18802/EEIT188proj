<template>
    <!-- <component :is="currentNavbar"></component> -->
<h1 style="font-family: Consolas, 'Courier New', monospace; font-size: xx-large;">403 Forbidden</h1>
</template>

<script setup>
// import { computed } from 'vue';
// import { useRoute } from 'vue-router';
// import EmpNavbar from '../employee_pages/EmpNavbar.vue';
// import CustNavbar from '../CustNavbar.vue';

// // 獲取當前路由
// const route = useRoute();

// // 定義 currentNavbar 計算屬性
// const currentNavbar = computed(() => {
//   return route.meta.navbar === 'CustNavbar' ? CustNavbar : EmpNavbar;
// });
</script>

<style>

</style>