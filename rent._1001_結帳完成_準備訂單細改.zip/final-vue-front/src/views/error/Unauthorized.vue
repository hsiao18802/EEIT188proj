<template>
<h1 style="font-family: Consolas, 'Courier New', monospace; font-size: xx-large;">401 Unauthorized</h1>
</template>

<script setup>

</script>

<style>

</style>